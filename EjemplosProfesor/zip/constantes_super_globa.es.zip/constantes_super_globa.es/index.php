<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Constantes y súper globales</title>
</head>

<body>
    <?php
        define("nombre","Luis");
        function escribeNombre(){
            echo "Hola ".nombre;
        }
        escribeNombre();
        echo "<hr>";
        foreach($_SERVER as $key => $value){
            echo "<b>$key: </b>$value<br>";
        }
    ?>
</body>

</html>