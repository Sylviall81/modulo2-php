<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recepcion formulario</title>
</head>
<body>
<?php
    if (isset($_POST["name"]) && isset($_POST["email"]) && $_POST['name']!='' && $_POST['email']!='') { ?>
        Welcome
        <?php echo $_POST["name"]; ?><br>
        Your email address is:
        <?php echo $_POST["email"]; ?>
    <?php } else {
        echo "ERROR, faltan parámetros";
        http_response_code(400);
    }
    ?>
</body>
</html>